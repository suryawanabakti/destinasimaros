import DestinationController from './DestinationController'
import ReviewController from './ReviewController'
import ReportController from './ReportController'
import Settings from './Settings'
const Controllers = {
    DestinationController: Object.assign(DestinationController, DestinationController),
ReviewController: Object.assign(ReviewController, ReviewController),
ReportController: Object.assign(ReportController, ReportController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers