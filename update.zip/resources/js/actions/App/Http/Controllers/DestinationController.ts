import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::index
 * @see app/Http/Controllers/DestinationController.php:13
 * @route '/'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: search.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
        searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::search
 * @see app/Http/Controllers/DestinationController.php:27
 * @route '/search'
 */
        searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    search.form = searchForm
/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
export const show = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/destinations/{destination}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.url = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destination: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { destination: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    destination: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destination: typeof args.destination === 'object'
                ? args.destination.id
                : args.destination,
                }

    return show.definition.url
            .replace('{destination}', parsedArgs.destination.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
    const showForm = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
        showForm.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
        showForm.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/destinations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::adminIndex
 * @see app/Http/Controllers/DestinationController.php:67
 * @route '/admin/destinations'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/destinations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::create
 * @see app/Http/Controllers/DestinationController.php:76
 * @route '/admin/destinations/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\DestinationController::store
 * @see app/Http/Controllers/DestinationController.php:81
 * @route '/admin/destinations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/destinations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DestinationController::store
 * @see app/Http/Controllers/DestinationController.php:81
 * @route '/admin/destinations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::store
 * @see app/Http/Controllers/DestinationController.php:81
 * @route '/admin/destinations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DestinationController::store
 * @see app/Http/Controllers/DestinationController.php:81
 * @route '/admin/destinations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinationController::store
 * @see app/Http/Controllers/DestinationController.php:81
 * @route '/admin/destinations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
export const edit = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/destinations/{destination}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
edit.url = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destination: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { destination: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    destination: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destination: typeof args.destination === 'object'
                ? args.destination.id
                : args.destination,
                }

    return edit.definition.url
            .replace('{destination}', parsedArgs.destination.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
edit.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
edit.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
    const editForm = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
        editForm.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::edit
 * @see app/Http/Controllers/DestinationController.php:122
 * @route '/admin/destinations/{destination}/edit'
 */
        editForm.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\DestinationController::update
 * @see app/Http/Controllers/DestinationController.php:129
 * @route '/admin/destinations/{destination}'
 */
export const update = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/destinations/{destination}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\DestinationController::update
 * @see app/Http/Controllers/DestinationController.php:129
 * @route '/admin/destinations/{destination}'
 */
update.url = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destination: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { destination: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    destination: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destination: typeof args.destination === 'object'
                ? args.destination.id
                : args.destination,
                }

    return update.definition.url
            .replace('{destination}', parsedArgs.destination.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::update
 * @see app/Http/Controllers/DestinationController.php:129
 * @route '/admin/destinations/{destination}'
 */
update.put = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\DestinationController::update
 * @see app/Http/Controllers/DestinationController.php:129
 * @route '/admin/destinations/{destination}'
 */
    const updateForm = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinationController::update
 * @see app/Http/Controllers/DestinationController.php:129
 * @route '/admin/destinations/{destination}'
 */
        updateForm.put = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DestinationController::destroy
 * @see app/Http/Controllers/DestinationController.php:176
 * @route '/admin/destinations/{destination}'
 */
export const destroy = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/destinations/{destination}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DestinationController::destroy
 * @see app/Http/Controllers/DestinationController.php:176
 * @route '/admin/destinations/{destination}'
 */
destroy.url = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destination: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { destination: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    destination: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destination: typeof args.destination === 'object'
                ? args.destination.id
                : args.destination,
                }

    return destroy.definition.url
            .replace('{destination}', parsedArgs.destination.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::destroy
 * @see app/Http/Controllers/DestinationController.php:176
 * @route '/admin/destinations/{destination}'
 */
destroy.delete = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DestinationController::destroy
 * @see app/Http/Controllers/DestinationController.php:176
 * @route '/admin/destinations/{destination}'
 */
    const destroyForm = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinationController::destroy
 * @see app/Http/Controllers/DestinationController.php:176
 * @route '/admin/destinations/{destination}'
 */
        destroyForm.delete = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\DestinationController::deleteImage
 * @see app/Http/Controllers/DestinationController.php:196
 * @route '/admin/destination-images/{image}'
 */
export const deleteImage = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteImage.url(args, options),
    method: 'delete',
})

deleteImage.definition = {
    methods: ["delete"],
    url: '/admin/destination-images/{image}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DestinationController::deleteImage
 * @see app/Http/Controllers/DestinationController.php:196
 * @route '/admin/destination-images/{image}'
 */
deleteImage.url = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { image: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { image: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    image: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return deleteImage.definition.url
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::deleteImage
 * @see app/Http/Controllers/DestinationController.php:196
 * @route '/admin/destination-images/{image}'
 */
deleteImage.delete = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteImage.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DestinationController::deleteImage
 * @see app/Http/Controllers/DestinationController.php:196
 * @route '/admin/destination-images/{image}'
 */
    const deleteImageForm = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteImage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DestinationController::deleteImage
 * @see app/Http/Controllers/DestinationController.php:196
 * @route '/admin/destination-images/{image}'
 */
        deleteImageForm.delete = (args: { image: number | { id: number } } | [image: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteImage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteImage.form = deleteImageForm
const DestinationController = { index, search, show, adminIndex, create, store, edit, update, destroy, deleteImage }

export default DestinationController