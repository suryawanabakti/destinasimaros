import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
export const show = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/destinations/{destination}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.url = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { destination: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { destination: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    destination: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        destination: typeof args.destination === 'object'
                ? args.destination.id
                : args.destination,
                }

    return show.definition.url
            .replace('{destination}', parsedArgs.destination.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
show.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
    const showForm = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
        showForm.get = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DestinationController::show
 * @see app/Http/Controllers/DestinationController.php:20
 * @route '/destinations/{destination}'
 */
        showForm.head = (args: { destination: number | { id: number } } | [destination: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const destinations = {
    show: Object.assign(show, show),
}

export default destinations