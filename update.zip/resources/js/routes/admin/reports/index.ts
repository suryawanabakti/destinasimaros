import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::index
 * @see app/Http/Controllers/ReportController.php:13
 * @route '/admin/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
export const visits = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visits.url(options),
    method: 'get',
})

visits.definition = {
    methods: ["get","head"],
    url: '/admin/reports/visits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
visits.url = (options?: RouteQueryOptions) => {
    return visits.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
visits.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visits.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
visits.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: visits.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
    const visitsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: visits.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
        visitsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visits.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::visits
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/visits'
 */
        visitsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visits.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    visits.form = visitsForm
/**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
export const userLogins = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userLogins.url(options),
    method: 'get',
})

userLogins.definition = {
    methods: ["get","head"],
    url: '/admin/reports/user-logins',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
userLogins.url = (options?: RouteQueryOptions) => {
    return userLogins.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
userLogins.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userLogins.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
userLogins.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userLogins.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
    const userLoginsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userLogins.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
        userLoginsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userLogins.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::userLogins
 * @see app/Http/Controllers/ReportController.php:27
 * @route '/admin/reports/user-logins'
 */
        userLoginsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userLogins.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userLogins.form = userLoginsForm
/**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
export const reviews = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})

reviews.definition = {
    methods: ["get","head"],
    url: '/admin/reports/reviews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
reviews.url = (options?: RouteQueryOptions) => {
    return reviews.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
reviews.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
reviews.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reviews.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
    const reviewsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reviews.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
        reviewsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::reviews
 * @see app/Http/Controllers/ReportController.php:38
 * @route '/admin/reports/reviews'
 */
        reviewsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reviews.form = reviewsForm
/**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/admin/reports/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::users
 * @see app/Http/Controllers/ReportController.php:49
 * @route '/admin/reports/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
const reports = {
    index: Object.assign(index, index),
visits: Object.assign(visits, visits),
userLogins: Object.assign(userLogins, userLogins),
reviews: Object.assign(reviews, reviews),
users: Object.assign(users, users),
}

export default reports