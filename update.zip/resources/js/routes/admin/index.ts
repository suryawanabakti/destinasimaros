import destinations from './destinations'
import reports from './reports'
import destinationImages from './destination-images'
import reviews from './reviews'
const admin = {
    destinations: Object.assign(destinations, destinations),
reports: Object.assign(reports, reports),
destinationImages: Object.assign(destinationImages, destinationImages),
reviews: Object.assign(reviews, reviews),
}

export default admin